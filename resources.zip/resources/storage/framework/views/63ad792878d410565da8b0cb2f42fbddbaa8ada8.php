<table class="table_detail_alat">
    <thead class="head_row">
        <tr>
            <th style="width:350px">Item alat</th>
            <th>Jumlah</th>
        </tr>
    </thead>
    <tbody class="body_row">
        <tr>
           <td>
               <div class="row alat_item">
                    <img src="<?php echo e(asset('page/assets/images/alat/alat_1.png')); ?>" class="img-alat">
                    <div class="text_alat_list">Piring bulat merah hitam</div>
               </div>
           </td>
           <td>  <div class="text_alat_jumlah">3 pcs</div> </td>
        </tr>
        <tr>
            <td>
                <div class="row alat_item">
                     <img src="<?php echo e(asset('page/assets/images/alat/alat_2.png')); ?>" class="img-alat">
                     <div class="text_alat_list">Piring bulat merah hitam</div>
                </div>
            </td>
            <td>  <div class="text_alat_jumlah">3 pcs</div> </td>
         </tr>
         <tr>
            <td>
                <div class="row alat_item">
                     <img src="<?php echo e(asset('page/assets/images/alat/alat_3.png')); ?>" class="img-alat">
                     <div class="text_alat_list">Piring bulat merah hitam</div>
                </div>
            </td>
            <td>  <div class="text_alat_jumlah">3 pcs</div> </td>
         </tr>
    </tbody>
</table><?php /**PATH C:\xampp\htdocs\kesiniku\resources\resources\views/page/keranjang/alat.blade.php ENDPATH**/ ?>