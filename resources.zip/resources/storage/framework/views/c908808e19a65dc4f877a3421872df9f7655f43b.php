
  <!-- Modal -->
  <div class="modal fade" id="exampleModalCenter" tabindex="-1" role="dialog" aria-labelledby="modal-title" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered" role="document">
      <div class="modal-content">
        <div class="modal-header" id="modal-header">
          <div class="modal-title text-center" id="modal-title">Modal title</div>
          <button type="button" class="close" data-dismiss="modal" aria-label="Close">
            <span aria-hidden="true">&times;</span>
          </button>
        </div>
        <div class="modal-body" id="modal-body">
            
        </div>
      </div>
    </div>
  </div><?php /**PATH C:\xampp\htdocs\kesiniku\resources\resources\views/headfood/modal.blade.php ENDPATH**/ ?>