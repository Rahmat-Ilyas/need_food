<?php $__env->startSection('konten'); ?>

<section class="banner_order">
    <div class="container">
        <div class="row">
            <div class="col-lg-12">
                <div class="box">
                    <div class="title_upload">Upload bukti pembayaran</div>
                    
                                              <b>Kode Pemesan: <?php echo e($pesanan->kd_pemesanan); ?></b><br>
<b>Nama Pemesan: <?php echo e($pesanan->nama); ?></b><br>
<b>Alamat: <?php echo e($pesanan->deskripsi_lokasi); ?></b><br>
<hr>
<br>

                    <div class="container">
                        <div class="sub_box">
                        <input type="hidden" id="pemesanan_id" value="<?php echo e($pesanan->id); ?>">
                            <form action="<?php echo e(url('/upload_dropzone')); ?>" class="dropzone" id="myAwesomeDropzone" style="border: none;">
                              <?php echo csrf_field(); ?>
                            </form>
                          </div>
                          <div class="notes_upload_title">Keterangan</div>
                          <div class="col-lg-8">
                            <div class="notes_upload_text">Lorem ipsum dolor sit amet, consectetur adipiscing elit.Fringilla sed tellus orci praesent sem eget. Amet eu, habitant id vel magna vitae</div>
                          </div>
                          <div class="col-lg-6">
                            <button id="upload_submit" class="tombol-custom tombol-keranjang text-button grid_upload">UPLOAD</button>
                          </div>
                    </div>

                </div>
            </div>
        </div>
    </div>
</section>

<div id="loading" hidden="">
  <span class="loader" hidden=""></span>
  <div class="textLoader">
      <center>
          <b>Please Wait ... </b>
      </center>
  </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('headfood.page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\kesiniku\resources\resources\views/page/upload/index.blade.php ENDPATH**/ ?>