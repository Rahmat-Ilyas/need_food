<?php

namespace App\Model;

use Illuminate\Database\Eloquent\Model;

class AddBahan extends Model
{
    protected $table = 'tb_add_bahan';
    protected $guarded = [];
}
