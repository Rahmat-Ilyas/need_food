<?php

namespace App\Model;

use Illuminate\Database\Eloquent\Model;

class SetAlat extends Model
{
    protected $table = 'tb_setalat';
    protected $guarded = [];
}
