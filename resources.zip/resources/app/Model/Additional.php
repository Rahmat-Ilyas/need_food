<?php

namespace App\Model;

use Illuminate\Database\Eloquent\Model;

class Additional extends Model
{
    protected $table = 'tb_additional';
    protected $guarded = [];
}
