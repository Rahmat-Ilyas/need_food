<?php

namespace App\Model;

use Illuminate\Database\Eloquent\Model;

class DataRekening extends Model
{
    protected $table = 'tb_rekening';
    protected $guarded = [];
}
