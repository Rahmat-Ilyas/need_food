<?php

namespace App\Model;

use Illuminate\Database\Eloquent\Model;

class Pemesanan extends Model
{
    protected $table = 'tb_pemesanan';
    protected $guarded = [];
}
