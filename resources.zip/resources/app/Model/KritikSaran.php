<?php

namespace App\Model;

use Illuminate\Database\Eloquent\Model;

class KritikSaran extends Model
{
    protected $table = 'tb_keritiksaran';
    protected $guarded = [];
}
