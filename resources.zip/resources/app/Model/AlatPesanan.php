<?php

namespace App\Model;

use Illuminate\Database\Eloquent\Model;

class AlatPesanan extends Model
{
    protected $table = 'tb_alatpesanan';
    protected $guarded = [];
}
