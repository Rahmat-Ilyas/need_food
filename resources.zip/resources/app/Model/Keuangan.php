<?php

namespace App\Model;

use Illuminate\Database\Eloquent\Model;

class Keuangan extends Model
{
    protected $table = 'tb_keuangan';
    protected $guarded = [];
}
