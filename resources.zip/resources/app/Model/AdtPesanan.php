<?php

namespace App\Model;

use Illuminate\Database\Eloquent\Model;

class AdtPesanan extends Model
{
    protected $table = 'tb_adtpesanan';
    protected $guarded = [];
}
