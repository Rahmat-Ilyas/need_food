<?php

namespace App\Model;

use Illuminate\Database\Eloquent\Model;

class AlatHilang extends Model
{
    protected $table = 'tb_alathilang';
    protected $guarded = [];
}
