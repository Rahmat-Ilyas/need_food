<?php

namespace App\Model;

use Illuminate\Database\Eloquent\Model;

class AddAlat extends Model
{
    protected $table = 'tb_add_alat';
    protected $guarded = [];
}
