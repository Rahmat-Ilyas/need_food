<?php

namespace App\Model;

use Illuminate\Database\Eloquent\Model;

class PaketPesanan extends Model
{
    protected $table = 'tb_paketpesanan';
    protected $guarded = [];
}
