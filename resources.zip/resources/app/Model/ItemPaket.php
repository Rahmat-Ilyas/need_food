<?php

namespace App\Model;

use Illuminate\Database\Eloquent\Model;

class ItemPaket extends Model
{
    protected $table = 'tb_item_paket';
    protected $guarded = [];
}
