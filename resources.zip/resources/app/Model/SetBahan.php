<?php

namespace App\Model;

use Illuminate\Database\Eloquent\Model;

class SetBahan extends Model
{
    protected $table = 'tb_setbahan';
    protected $guarded = [];
}
