<?php

namespace App\Model;

use Illuminate\Database\Eloquent\Model;

class Bahan extends Model
{
    protected $table = 'tb_bahan';
    protected $guarded = [];
}
