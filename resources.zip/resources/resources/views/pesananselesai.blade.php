<h2>Terima kasih telah memesan di kesiniku, driver kami akan segera datang mengambil peralatan. Mohon untuk di siapkan</h2>
<h2>Terima kasih</h2>
<a href="kesiniku.com">kesiniku.com</a>