<div class="container">
    <div class="row">
        <div class="col-lg-8 menu_grid">
            <div class="row">
                <div class="col-lg-12 img-paket">
                    
                </div>
                <div class="col-lg-8 ratings">
                 
                </div>
                <div class="row">
                    <div class="container">
                        <div class="col-lg-12 group_text_order">
                            
                        </div>
                        <div class="tampung_value">

                        </div>
                    </div>
                </div>

            </div>
        </div>

        <div class="col-lg-4">
            <div class="grid_group_button_order">
                <div class="paket_general">
                    <p id="nominals">
                         
                    </p>
                </div>
                <div class="row">
                    <div class="col-sm-12 form_qty">
                        
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-sm-12 action_data">
                    
                </div>
            </div>
        </div>
    </div>
</div>